package com.awantikainternship.jdbccode;
import java.sql.*;
import java.util.*;

public class MobileDb {
	public static void main(String[] args) {
		Connection con;
		PreparedStatement pst;
		Scanner sc=new Scanner(System.in);
		int no,pc,rt;
		String nm,cp,co,rm,cl,sr,bt,pr;
		float ro;
		
		try
		{

			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://b9cvnkczmh5zhxvxwzfi-mysql.services.clever-cloud.com:3306/b9cvnkczmh5zhxvxwzfi?user=uwapzwun5twfji3l&password=3XYhpLCBo4G7PeGQEBM4");
			pst=con.prepareStatement("insert into MOBILES values(?,?,?,?,?,?,?,?,?,?,?,?)");
			
			System.out.print("Enter Product ID : ");
			no=sc.nextInt();
			sc.nextLine();
			System.out.print("Enter Model Name : ");
			nm=sc.nextLine();
			System.out.print("Enter Company : ");
			cp=sc.nextLine();
			System.out.print("Enter Connectivity : ");
			co=sc.nextLine();
			System.out.print("Enter RAM : ");
			rm=sc.nextLine();
			System.out.print("Enter ROM : ");
			ro=sc.nextFloat();
			System.out.print("Enter Color : ");
			cl=sc.nextLine();
			sc.nextLine();
			System.out.print("Enter Screen : ");
			sr=sc.nextLine();
			System.out.print("Enter Battery : ");
			bt=sc.nextLine();
			System.out.print("Enter Processor : ");
			pr=sc.nextLine();
			System.out.print("Enter Price : ");
			pc=sc.nextInt();
			System.out.print("Enter Rating : ");
			rt=sc.nextInt();
			
			pst.setInt(1, no);
			pst.setString(2,nm);
			pst.setString(3, cp);
			pst.setString(4, co);
			pst.setString(5, rm);
			pst.setFloat(6, ro);
			pst.setString(7, cl);
			pst.setString(8, sr);
			pst.setString(9, bt);
			pst.setString(10, pr);
			pst.setInt(11, pc);
			pst.setInt(12, rt);
			pst.executeUpdate();
			
			System.out.println("New Mobile Data added successfully");
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
