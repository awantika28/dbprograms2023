package com.awantikainternship.jdbccode;
import java.sql.*;

public class GroupByInfo {
    public static void main(String[] args) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            // Establish the database connection
        	try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            con = DriverManager.getConnection("jdbc:mysql://b9cvnkczmh5zhxvxwzfi-mysql.services.clever-cloud.com:3306/b9cvnkczmh5zhxvxwzfi?user=uwapzwun5twfji3l&password=3XYhpLCBo4G7PeGQEBM4");

            // Create a statement object
            stmt = con.createStatement();

            // Execute the SQL query
            String query = "SELECT company, COUNT(modelname) AS totalModels, AVG(price) AS averagePrice, AVG(rating) AS averageRating FROM mobiles GROUP BY company";
            rs = stmt.executeQuery(query);

            // Display the group by information
            while (rs.next()) {
                String company = rs.getString("company");
                int totalModels = rs.getInt("totalModels");
                double averagePrice = rs.getDouble("averagePrice");
                double averageRating = rs.getDouble("averageRating");

                System.out.println("Company: " + company);
                System.out.println("Total Models: " + totalModels);
                System.out.println("Average Price: " + averagePrice);
                System.out.println("Average Rating: " + averageRating);
                System.out.println("------------------------");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the connections and resources
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
