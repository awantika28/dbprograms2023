package com.awantikainternship.jdbccode;
import java.sql.*;
import java.util.*;

public class DeleteMobile {
	public static void main(String[] args) {
		Connection con;
		PreparedStatement pst;
		Scanner sc=new Scanner(System.in);
		int no;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://b9cvnkczmh5zhxvxwzfi-mysql.services.clever-cloud.com:3306/b9cvnkczmh5zhxvxwzfi?user=uwapzwun5twfji3l&password=3XYhpLCBo4G7PeGQEBM4");
			pst=con.prepareStatement("delete from MOBILES where prodid=?");
			
			System.out.print("Enter Product ID to delete : ");
			no=sc.nextInt();
			
			pst.setInt(1, no);
			int cnt=pst.executeUpdate();
			if(cnt>0)
				System.out.println("mobile deleted successfully");
			else
				System.out.println("mobile not found");
			
			con.close();
			
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
