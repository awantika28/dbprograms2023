package com.awantikainternship.jdbccode;
import java.sql.*;
import java.util.*;

public class UpdatePrice {
    public static void main(String[] args) {
        Connection con;
        PreparedStatement pst;
        Scanner sc = new Scanner(System.in);
        int prodId;
        float newPrice;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://b9cvnkczmh5zhxvxwzfi-mysql.services.clever-cloud.com:3306/b9cvnkczmh5zhxvxwzfi?user=uwapzwun5twfji3l&password=3XYhpLCBo4G7PeGQEBM4");
            pst = con.prepareStatement("UPDATE MOBILES SET price = ? WHERE prodid = ?");

            System.out.print("Enter Mobile ID: ");
            prodId = sc.nextInt();
            System.out.print("Enter new Price: ");
            newPrice = sc.nextFloat();

            pst.setFloat(1, newPrice);
            pst.setInt(2, prodId);
            int rowCount = pst.executeUpdate();

            if (rowCount == 1) {
                System.out.println("Price Changed Successfully");
            } else {
                System.out.println("Mobile does not Exist");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
