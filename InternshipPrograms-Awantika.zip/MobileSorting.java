package com.awantikainternship.jdbccode;
import java.sql.*;
import java.util.Scanner;

public class MobileSorting {
    public static void main(String[] args) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            // Establish the database connection
        	try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            con = DriverManager.getConnection("jdbc:mysql://b9cvnkczmh5zhxvxwzfi-mysql.services.clever-cloud.com:3306/b9cvnkczmh5zhxvxwzfi?user=uwapzwun5twfji3l&password=3XYhpLCBo4G7PeGQEBM4");

            // Create a statement object
            stmt = con.createStatement();

            // Create a Scanner object to read user input
            Scanner scanner = new Scanner(System.in);

            // Accept the field name from the user
            System.out.print("Enter the field name (e.g., rom): ");
            String field = scanner.nextLine();

            // Construct the SQL query with backticks around the field name
            String query = "SELECT * FROM mobiles ORDER BY `" + field + "` DESC";

            // Execute the SQL query
            rs = stmt.executeQuery(query);

            // Display the mobiles in descending order of the specified field
            while (rs.next()) {
                String modelname = rs.getString("modelname");
                int ram = rs.getInt("ram");
                int rom = rs.getInt("rom");
                double price = rs.getDouble("price");
                double rating = rs.getDouble("rating");

                System.out.println("Model Name: " + modelname);
                System.out.println("RAM: " + ram);
                System.out.println("ROM: " + rom);
                System.out.println("Price: " + price);
                System.out.println("Rating: " + rating);
                System.out.println("------------------------");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the connections and resources
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
