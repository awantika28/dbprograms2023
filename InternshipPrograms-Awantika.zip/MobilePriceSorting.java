package com.awantikainternship.jdbccode;
import java.sql.*;
import java.util.*;

public class MobilePriceSorting {
    public static void main(String[] args) {
        Connection con;
        PreparedStatement pst;
        ResultSet rs = null;
        Scanner sc = new Scanner(System.in);

        try {
            // Establish the database connection
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            con = DriverManager.getConnection("jdbc:mysql://b9cvnkczmh5zhxvxwzfi-mysql.services.clever-cloud.com:3306/b9cvnkczmh5zhxvxwzfi?user=uwapzwun5twfji3l&password=3XYhpLCBo4G7PeGQEBM4");

            // Prompt for company name
            System.out.print("Enter the company name: ");
            String company = sc.nextLine();

            // Prepare the SQL query
            String query = "SELECT * FROM MOBILES WHERE company = ? ORDER BY price ASC";

            // Create the prepared statement
            PreparedStatement pst1 = con.prepareStatement(query);
            pst1.setString(1, company);

            // Execute the query
            ResultSet resultSet = pst1.executeQuery();

            // Display the mobiles in ascending order of price
            System.out.println("Mobiles by " + company + " in ascending order of price:");
            while (resultSet.next()) {
                String modelName = resultSet.getString("modelname");
                double price = resultSet.getDouble("price");
                System.out.println(modelName + " Rs." + price);
            }

            // Close the connections and resources
            resultSet.close();
            pst1.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
