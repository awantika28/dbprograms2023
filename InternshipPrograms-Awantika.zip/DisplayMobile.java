package com.awantikainternship.jdbccode;

import java.sql.*;

public class DisplayMobile {
	public static void main(String[] args) {
		Connection con;
		Statement st;
		ResultSet rs;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://b9cvnkczmh5zhxvxwzfi-mysql.services.clever-cloud.com:3306/b9cvnkczmh5zhxvxwzfi?user=uwapzwun5twfji3l&password=3XYhpLCBo4G7PeGQEBM4");

			st=con.createStatement();
			rs=st.executeQuery("select * from MOBILES");
			
			while(rs.next())
			{
				System.out.println(rs.getString("modelname")+" | "+rs.getString("price"));
			}
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
}
