package com.awantikainternship.jdbccode;
import java.sql.*;
import java.util.*;

public class ReducePrice {
    public static void main(String[] args) {
        Connection con;
        CallableStatement cst;
        Scanner sc = new Scanner(System.in);
        String company;
        double amount;

        try {
            // Establish the database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://b9cvnkczmh5zhxvxwzfi-mysql.services.clever-cloud.com:3306/b9cvnkczmh5zhxvxwzfi?user=uwapzwun5twfji3l&password=3XYhpLCBo4G7PeGQEBM4");

            // Accept the company name and amount from the user
            System.out.print("Enter Company Name: ");
            company = sc.nextLine();
            System.out.print("Enter Amount to Reduce: ");
            amount = sc.nextDouble();

            // Prepare and execute the stored procedure call
            String query = "{CALL ReducePriceByAmount(?, ?)}";
            cst = con.prepareCall(query);
            cst.setString(1, company);
            cst.setDouble(2, amount);
            cst.execute();

            System.out.println("Price reduced successfully.");

            // Close the connections and resources
            cst.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

