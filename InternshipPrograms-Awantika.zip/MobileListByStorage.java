package com.awantikainternship.jdbccode;
import java.sql.*;
import java.util.*;

public class MobileListByStorage {
    public static void main(String[] args) {
        Connection con;
        PreparedStatement pst;
        ResultSet rs;
        Scanner sc = new Scanner(System.in);
        int ram;
        int rom;

        try {
            // Establish the database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://b9cvnkczmh5zhxvxwzfi-mysql.services.clever-cloud.com:3306/b9cvnkczmh5zhxvxwzfi?user=uwapzwun5twfji3l&password=3XYhpLCBo4G7PeGQEBM4");

            // Accept the RAM and ROM values from the user
            System.out.print("Enter RAM (in GB): ");
            ram = sc.nextInt();
            System.out.print("Enter ROM (in GB): ");
            rom = sc.nextInt();

            // Prepare the SQL query
            String query = "SELECT * FROM MOBILES WHERE ram = ? AND rom = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, ram);
            pst.setInt(2, rom);

            // Execute the query
            rs = pst.executeQuery();

            // Display the list of mobiles with the specified RAM and ROM storage space combination
            System.out.println("Mobiles with RAM " + ram + "GB and ROM " + rom + "GB:");
            while (rs.next()) {
                int prodId = rs.getInt("prodid");
                String modelName = rs.getString("modelname");
                double price = rs.getDouble("price");
                System.out.println("ProdID: " + prodId + ", Model Name: " + modelName + ", Price: $" + price);
            }

            // Close the connections and resources
            rs.close();
            pst.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
