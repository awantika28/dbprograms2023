package com.awantikainternship.jdbccode;

import java.sql.*;
import java.util.*;

public class FindModelName {
	public static void main(String[] args) {
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		String nm;
		Scanner sc=new Scanner(System.in);
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://b9cvnkczmh5zhxvxwzfi-mysql.services.clever-cloud.com:3306/b9cvnkczmh5zhxvxwzfi?user=uwapzwun5twfji3l&password=3XYhpLCBo4G7PeGQEBM4");
			pst=con.prepareStatement("select * from MOBILES where modelname=?");
			
			System.out.print("Enter Model Name to search : ");
			nm=sc.nextLine();
			
			pst.setString(1, nm);
			rs=pst.executeQuery();
			
			if(rs.next())
			{
				System.out.println("prodid : "+rs.getInt("prodid"));
				System.out.println("Company : "+rs.getString("company"));
				System.out.println("Connectivity : "+rs.getString("connectivity"));
				System.out.println("Ram : "+rs.getString("ram"));
				System.out.println("Rom : "+rs.getString("rom"));
				System.out.println("Color : "+rs.getString("color"));
				System.out.println("Screen : "+rs.getString("screen"));
				System.out.println("Battery : "+rs.getString("battery"));
				System.out.println("Processor : "+rs.getString("processor"));
				System.out.println("Price : "+rs.getDouble("price"));
				System.out.println("Rating : "+rs.getDouble("rating"));
				
                
			}
			else
				System.out.println("Model Name Not Found");
			con.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}