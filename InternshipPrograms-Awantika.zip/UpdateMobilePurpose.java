package com.awantikainternship.jdbccode;
import java.sql.*;
import java.util.*;

public class UpdateMobilePurpose {
    public static void main(String[] args) {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        String company, purpose;

        try {
            // Establish the database connection
        	try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            con = DriverManager.getConnection("jdbc:mysql://b9cvnkczmh5zhxvxwzfi-mysql.services.clever-cloud.com:3306/b9cvnkczmh5zhxvxwzfi?user=uwapzwun5twfji3l&password=3XYhpLCBo4G7PeGQEBM4");

            // Create a Scanner object to read user input
            Scanner scanner = new Scanner(System.in);

            // Accept model name and purpose from user
            System.out.print("Enter company name: ");
            company = scanner.nextLine();

            System.out.print("Enter purpose: ");
            purpose = scanner.nextLine();

            // Prepare the SQL query
            String query = "UPDATE mobiles SET purpose = ? WHERE company = ?";
            pst = con.prepareStatement(query);

            // Set the values for the prepared statement parameters
            pst.setString(1, purpose);
            pst.setString(2, company);

            // Execute the update query
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Number of rows updated: " + rowsAffected);
            } else {
                System.out.println("No rows updated. The specified model name may not exist.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the connections and resources
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
